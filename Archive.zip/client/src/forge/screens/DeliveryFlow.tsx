import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { AnimatePresence, LayoutGroup, motion } from "framer-motion";
import { ArrowUpRight, ChevronRight, Filter, ListFilter, MessageSquare, Network, Plus, ShieldCheck, Sparkles, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { buildScreenPath } from "@/forge/data";
import { useForge } from "@/forge/context";
import type { RiskLevel, StoryPhase } from "@/forge/types";
import { cn } from "@/lib/utils";
import { StoryTransitionDialog } from "@/forge/components/StoryTransitionDialog";
import { GitHubPanel } from "@/forge/components/GitHubPanel";
import { StoryDetailDrawer } from "@/forge/components/StoryDetailDrawer";
import { StoryCreateDialog } from "@/forge/components/StoryCreateDialog";
import { ReworkBadge } from "@/forge/components/ReworkBadge";

const phases: StoryPhase[] = ["Plan", "Design", "Develop", "Test", "Ship"];
const riskOptions: Array<RiskLevel | "All"> = ["All", "Low", "Medium", "High"];

type SortKey = "priority" | "confidence" | "owner";

export function DeliveryFlowScreen() {
  const { activePersona, selectedStory, setSelectedStoryId, stories, openStoryDrawer } = useForge();
  const [, setLocation] = useLocation();
  const [riskFilter, setRiskFilter] = useState<RiskLevel | "All">("All");
  const [sortKey, setSortKey] = useState<SortKey>("priority");
  const [myStories, setMyStories] = useState(false);
  const [transitionOpen, setTransitionOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);

  const visibleStories = useMemo(() => {
    const filtered = stories.filter(story => {
      if (riskFilter !== "All" && story.risk !== riskFilter) return false;
      if (myStories && (story.personaActions[activePersona] ?? []).length === 0) return false;
      return true;
    });

    return [...filtered].sort((left, right) => {
      if (sortKey === "confidence") {
        return right.confidence - left.confidence;
      }

      if (sortKey === "owner") {
        return left.owner.localeCompare(right.owner);
      }

      const riskWeight: Record<RiskLevel, number> = {
        High: 3,
        Medium: 2,
        Low: 1,
      };

      return riskWeight[right.risk] - riskWeight[left.risk];
    });
  }, [riskFilter, sortKey, myStories, activePersona, stories]);

  const grouped = useMemo(() => {
    return phases.map(phase => ({
      phase,
      stories: visibleStories.filter(story => story.phase === phase),
    }));
  }, [visibleStories]);

  const relatedContext = selectedStory.memoryEvents.slice(0, 2);
  const relatedControls = selectedStory.controls.slice(0, 2);

  const openStory = (storyId: string) => {
    setSelectedStoryId(storyId);
    setLocation(buildScreenPath("delivery", storyId));
    openStoryDrawer(storyId);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-[20px] border border-slate-200 bg-white p-5 shadow-[0_20px_50px_-40px_rgba(15,23,42,0.22)]">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-slate-500">Governed execution</p>
            <h3 className="mt-2 font-[family-name:var(--font-display)] text-[2rem] font-semibold tracking-[-0.04em] text-slate-950">A believable end to end workspace across all five phases</h3>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-600">The selected story remains active while filters, sorting, memory, architecture, and governance stay connected to the same work item.</p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="flex flex-wrap gap-2">
              {riskOptions.map(option => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setRiskFilter(option)}
                  className={cn(
                    "rounded-full border px-3 py-1.5 text-sm font-semibold transition",
                    riskFilter === option
                      ? "border-slate-900 bg-slate-950 text-white"
                      : "border-slate-200 bg-white text-slate-600 hover:border-sky-200 hover:text-slate-900"
                  )}
                >
                  {option} risk
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setMyStories(v => !v)}
              className={cn(
                "inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm font-semibold transition",
                myStories
                  ? "border-sky-600 bg-sky-600 text-white"
                  : "border-slate-200 bg-white text-slate-600 hover:border-sky-200 hover:text-slate-900"
              )}
            >
              <User className="size-4" />
              My stories
            </button>

            <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-sm text-slate-600">
              <ListFilter className="size-4 text-slate-400" />
              <select
                value={sortKey}
                onChange={event => setSortKey(event.target.value as SortKey)}
                className="bg-transparent font-semibold text-slate-700 outline-none"
              >
                <option value="priority">Sort by priority</option>
                <option value="confidence">Sort by confidence</option>
                <option value="owner">Sort by owner</option>
              </select>
            </div>

            <Button
              onClick={() => setCreateOpen(true)}
              className="flex items-center gap-2 rounded-full bg-slate-950 text-white hover:bg-slate-800"
            >
              <Plus className="size-4" />
              Create Story
            </Button>
          </div>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.55fr)_360px]">
        <section className="rounded-[20px] border border-slate-200 bg-white p-5 shadow-[0_20px_50px_-40px_rgba(15,23,42,0.22)]">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-slate-500">Delivery board</p>
              <h3 className="mt-2 text-xl font-semibold text-slate-950">Flow stays readable across desktop and smaller workspaces</h3>
            </div>
            <div className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1.5 text-sm font-semibold text-slate-600">
              <Filter className="size-4" />
              {visibleStories.length} visible stories
            </div>
          </div>

          <LayoutGroup>
            <div className="mt-5 grid gap-4 md:grid-cols-2 2xl:grid-cols-5">
              {grouped.map(group => (
                <div key={group.phase} className="rounded-[18px] border border-slate-200 bg-slate-50/60 p-4">
                  <div className="mb-3 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold text-slate-950">{group.phase}</p>
                      <p className="text-sm text-slate-500">{group.stories.length} active stories</p>
                    </div>
                    <span className="rounded-full bg-white px-2.5 py-1 text-[11px] font-semibold text-slate-600 ring-1 ring-slate-200">{group.phase === selectedStory.phase ? "Current" : "Phase"}</span>
                  </div>

                  <div className="space-y-3">
                    <AnimatePresence mode="popLayout">
                      {group.stories.length ? (
                        group.stories.map(story => (
                          <motion.button
                            key={story.id}
                            layoutId={story.id}
                            layout
                            initial={{ opacity: 0, scale: 0.96 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.96 }}
                            transition={{ type: "spring", damping: 25, stiffness: 300 }}
                            type="button"
                            onClick={() => openStory(story.id)}
                            className={cn(
                              "w-full rounded-[16px] border p-4 text-left",
                              story.id === selectedStory.id
                                ? "border-slate-900 bg-slate-950 text-white shadow-[0_20px_40px_-30px_rgba(15,23,42,0.7)]"
                                : "border-slate-200 bg-white hover:border-sky-200 hover:bg-sky-50/40"
                            )}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div>
                                <p className={cn("text-base font-semibold", story.id === selectedStory.id ? "text-white" : "text-slate-950")}>{story.title}</p>
                                <p className={cn("mt-1 text-sm", story.id === selectedStory.id ? "text-white/70" : "text-slate-500")}>{story.owner}</p>
                              </div>
                              <span className={cn(
                                "rounded-full px-2.5 py-1 text-[11px] font-semibold ring-1",
                                story.id === selectedStory.id
                                  ? "bg-white/10 text-white ring-white/20"
                                  : story.risk === "High"
                                    ? "bg-amber-50 text-amber-700 ring-amber-100"
                                    : story.risk === "Medium"
                                      ? "bg-sky-50 text-sky-700 ring-sky-100"
                                      : "bg-emerald-50 text-emerald-700 ring-emerald-100"
                              )}>{story.risk} risk</span>
                            </div>
                            <p className={cn("mt-3 text-sm leading-6", story.id === selectedStory.id ? "text-white/80" : "text-slate-600")}>{story.summary}</p>
                            <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/20">
                              <motion.div
                                className={cn("h-full rounded-full", story.id === selectedStory.id ? "bg-white" : "bg-sky-500")}
                                initial={{ width: 0 }}
                                animate={{ width: `${story.confidence}%` }}
                                transition={{ duration: 0.6, ease: "easeOut" }}
                              />
                            </div>
                            <div className="mt-3 flex flex-wrap gap-2">
                              <span className={cn("rounded-full px-2.5 py-1 text-[11px] font-semibold", story.id === selectedStory.id ? "bg-white/10 text-white" : "bg-slate-100 text-slate-600")}>{story.memoryLinks} memory links</span>
                              <span className={cn("rounded-full px-2.5 py-1 text-[11px] font-semibold", story.id === selectedStory.id ? "bg-white/10 text-white" : "bg-slate-100 text-slate-600")}>{story.confidence}% confidence</span>
                            </div>
                            {story.agentOutputs?.[story.phase]?.sections?.some(s => s.status === "reworked") && (
                              <div className="mt-2">
                                <ReworkBadge status="reworked" />
                              </div>
                            )}
                            {(story.feedbackHistory?.length ?? 0) > 0 && (
                              <div className={cn(
                                "mt-2 flex items-center gap-1.5 text-[11px] font-semibold",
                                story.id === selectedStory.id ? "text-white/70" : "text-slate-500"
                              )}>
                                <MessageSquare className="size-3.5" />
                                {story.feedbackHistory!.length} {story.feedbackHistory!.length === 1 ? "comment" : "comments"}
                              </div>
                            )}
                          </motion.button>
                        ))
                      ) : (
                        <div className="rounded-[16px] border border-dashed border-slate-200 bg-white px-4 py-8 text-center">
                          <p className="text-sm font-semibold text-slate-900">No stories in {group.phase}</p>
                          <p className="mt-2 text-sm leading-6 text-slate-600">Adjust the risk filter or move a story forward to populate this phase.</p>
                        </div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              ))}
            </div>
          </LayoutGroup>
        </section>

        <section className="space-y-4">
          <div className="rounded-[20px] border border-slate-200 bg-white p-5 shadow-[0_20px_50px_-40px_rgba(15,23,42,0.22)]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-slate-500">Active story</p>
                <h3 className="mt-2 text-xl font-semibold text-slate-950">{selectedStory.title}</h3>
              </div>
              <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-semibold text-slate-600 ring-1 ring-slate-200">{selectedStory.phase}</span>
            </div>
            <p className="mt-3 text-sm leading-7 text-slate-600">{selectedStory.personaFocus[activePersona] ?? ""}</p>
            <div className="mt-4 space-y-3">
              {(selectedStory.personaActions[activePersona] ?? []).map(action => (
                <div key={action} className="rounded-[14px] border border-slate-200 bg-slate-50/60 px-4 py-3 text-sm font-medium text-slate-800">{action}</div>
              ))}
            </div>
            {selectedStory.phase !== "Ship" && (
              <Button
                onClick={() => setTransitionOpen(true)}
                className="mt-4 flex w-full items-center justify-center gap-2 bg-slate-950 text-white hover:bg-slate-800"
              >
                <ArrowUpRight className="size-4" />
                Advance to next phase
              </Button>
            )}
          </div>

          <GitHubPanel defaultView="prs" maxItems={4} />

          <StoryTransitionDialog story={selectedStory} open={transitionOpen} onOpenChange={setTransitionOpen} />

          <div className="rounded-[20px] border border-slate-200 bg-white p-5 shadow-[0_20px_50px_-40px_rgba(15,23,42,0.22)]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-slate-500">Related surfaces</p>
                <h3 className="mt-2 text-xl font-semibold text-slate-950">This story is already connected beyond delivery</h3>
              </div>
              <ChevronRight className="size-4 text-sky-700" />
            </div>

            <div className="mt-4 space-y-3">
              <button
                type="button"
                onClick={() => setLocation(buildScreenPath("context", selectedStory.id))}
                className="flex w-full items-start gap-3 rounded-[16px] border border-slate-200 bg-slate-50/60 p-4 text-left transition hover:border-sky-200 hover:bg-white"
              >
                <span className="rounded-2xl bg-emerald-50 p-2 text-emerald-700 ring-1 ring-emerald-100"><Sparkles className="size-4" /></span>
                <span>
                  <span className="block text-sm font-semibold text-slate-950">Context Hub</span>
                  <span className="mt-1 block text-sm leading-6 text-slate-600">{relatedContext[0]?.title ?? "Memory links are available for this story."}</span>
                </span>
              </button>

              <button
                type="button"
                onClick={() => setLocation(buildScreenPath("architecture", selectedStory.id))}
                className="flex w-full items-start gap-3 rounded-[16px] border border-slate-200 bg-slate-50/60 p-4 text-left transition hover:border-sky-200 hover:bg-white"
              >
                <span className="rounded-2xl bg-sky-50 p-2 text-sky-700 ring-1 ring-sky-100"><Network className="size-4" /></span>
                <span>
                  <span className="block text-sm font-semibold text-slate-950">Architecture</span>
                  <span className="mt-1 block text-sm leading-6 text-slate-600">{selectedStory.serviceImpacts[0]?.detail}</span>
                </span>
              </button>

              <button
                type="button"
                onClick={() => setLocation(buildScreenPath("governance", selectedStory.id))}
                className="flex w-full items-start gap-3 rounded-[16px] border border-slate-200 bg-slate-50/60 p-4 text-left transition hover:border-sky-200 hover:bg-white"
              >
                <span className="rounded-2xl bg-amber-50 p-2 text-amber-700 ring-1 ring-amber-100"><ShieldCheck className="size-4" /></span>
                <span>
                  <span className="block text-sm font-semibold text-slate-950">Governance</span>
                  <span className="mt-1 block text-sm leading-6 text-slate-600">{relatedControls[0]?.detail ?? "Control posture is being tracked for this story."}</span>
                </span>
              </button>
            </div>
          </div>
        </section>
      </div>

      <StoryDetailDrawer />
      <StoryCreateDialog open={createOpen} onOpenChange={setCreateOpen} />
    </div>
  );
}
